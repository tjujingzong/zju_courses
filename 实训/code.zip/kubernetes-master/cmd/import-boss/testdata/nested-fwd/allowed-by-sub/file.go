package allowedbysub

var X = "allowedbysub"
