package forbiddenbyboth

var X = "forbiddenbyboth"
